#version 120

uniform vec2 u_size;
uniform float u_radius;
uniform float u_border_size;
uniform float u_start_angle;
uniform float u_sweep_angle;
uniform vec4 u_color;

const float PI = 3.14159265358979323846;

void main(void) {
    vec2 tex = gl_TexCoord[0].st;
    vec2 center = u_size * 0.5;
    vec2 fragPos = tex * u_size;

    vec2 dir = fragPos - center;
    float dist = length(dir);

    // Radial distance mask with smoothstep anti-aliasing
    float outer = smoothstep(u_radius + 0.5, u_radius - 0.5, dist);
    float inner = smoothstep(u_radius - u_border_size + 0.5, u_radius - u_border_size - 0.5, dist);
    float radialAlpha = outer - inner;

    // Angle calculation: atan(-dir.y, dir.x) -> angle from 3 o'clock clockwise
    // dir.y is positive downward in screen coordinates
    float angle = atan(dir.y, dir.x); // radians in [-PI, PI]
    float deg = degrees(angle); // [-180, 180]
    
    // Normalize to [0, 360)
    if (deg < 0.0) {
        deg += 360.0;
    }

    // Offset by start angle
    float normStart = mod(u_start_angle, 360.0);
    if (normStart < 0.0) {
        normStart += 360.0;
    }

    float relAngle = mod(deg - normStart, 360.0);
    if (relAngle < 0.0) {
        relAngle += 360.0;
    }

    // Angular anti-aliasing
    float angleEdge = 0.5 / max(dist, 1.0) * (180.0 / PI); // pixel width in degrees
    float startMask = smoothstep(0.0, angleEdge, relAngle);
    float endMask = smoothstep(u_sweep_angle, u_sweep_angle - angleEdge, relAngle);
    float angleAlpha = min(startMask, endMask);

    float finalAlpha = radialAlpha * angleAlpha;
    gl_FragColor = vec4(u_color.rgb, u_color.a * finalAlpha);
}